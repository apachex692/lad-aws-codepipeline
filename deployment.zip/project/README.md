# Nginx and Flask Containerization and Orchestration

This project containerizes a Flask application and Nginx proxy and orchestrates them to work together as a deployment environment web server.

- **Author:** Sakthi Santhosh
- **Created on:** 25/09/2023

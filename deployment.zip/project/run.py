# Author: Sakthi Santhosh
# Created on: 25/09/2023
def main() -> int:
    from app import app_handle

    app_handle.run()

if __name__ == "__main__":
    exit(main())

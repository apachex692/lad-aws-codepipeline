#!/bin/bash
#
# Author: Sakthi Santhosh
# Created on: 05/10/2023
cd /app/project/

/home/ec2-user/.local/bin/docker-compose up -d
